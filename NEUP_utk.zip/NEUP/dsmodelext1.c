#include <moutil.c>
PreNonAliasDef(6)
PreNonAliasDef(7)
PreNonAliasDef(8)
PreNonAliasDef(9)
PreNonAliasDef(10)
StartNonAlias(5)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.sat_out.Tsat", "Saturation temperature [K|degC]",\
 500, 273.15,2273.15,500.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.bubble_in.phase", "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 1, 0.0,2.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.bubble_in.h", "Specific enthalpy [J/kg]",\
 100000.0, -10000000000.0,10000000000.0,500000.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.bubble_in.d", "Density [kg/m3|g/cm3]",\
 150, 0.0,100000.0,500.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.bubble_in.T", "Temperature [K|degC]", \
"nuScaleBOP_v1_1.LPTurbine.sat_in.Tsat", 1, 5, 5667, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.bubble_in.p", "Pressure [Pa|bar]", \
"nuScaleBOP_v1_1.LPTurbine.sat_in.psat", 1, 5, 5666, 0)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.dew_in.phase", "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 1, 0.0,2.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.dew_in.h", "Specific enthalpy [J/kg]",\
 100000.0, -10000000000.0,10000000000.0,500000.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.dew_in.d", "Density [kg/m3|g/cm3]", 150,\
 0.0,100000.0,500.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.dew_in.T", "Temperature [K|degC]", \
"nuScaleBOP_v1_1.LPTurbine.sat_in.Tsat", 1, 5, 5667, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.dew_in.p", "Pressure [Pa|bar]", \
"nuScaleBOP_v1_1.LPTurbine.sat_in.psat", 1, 5, 5666, 0)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.bubble_out.phase", "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 1, 0.0,2.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.bubble_out.h", "Specific enthalpy [J/kg]",\
 100000.0, -10000000000.0,10000000000.0,500000.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.bubble_out.d", "Density [kg/m3|g/cm3]",\
 150, 0.0,100000.0,500.0,0,513)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.bubble_out.T", "Temperature [K|degC]", \
"nuScaleBOP_v1_1.LPTurbine.sat_out.Tsat", 1, 5, 5669, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.bubble_out.p", "Pressure [Pa|bar]", \
"nuScaleBOP_v1_1.LPTurbine.sat_out.psat", 1, 5, 5668, 0)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.dew_out.phase", "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 1, 0.0,2.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.dew_out.h", "Specific enthalpy [J/kg]",\
 100000.0, -10000000000.0,10000000000.0,500000.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.dew_out.d", "Density [kg/m3|g/cm3]", 150,\
 0.0,100000.0,500.0,0,513)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.dew_out.T", "Temperature [K|degC]", \
"nuScaleBOP_v1_1.LPTurbine.sat_out.Tsat", 1, 5, 5669, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.dew_out.p", "Pressure [Pa|bar]", \
"nuScaleBOP_v1_1.LPTurbine.sat_out.psat", 1, 5, 5668, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.h_fsat_in", "Saturated liquid specific enthalpy at inlet [J/kg]",\
 "nuScaleBOP_v1_1.LPTurbine.bubble_in.h", 1, 5, 5671, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.h_gsat_in", "Saturated vapor specific enthalpy  at inlet [J/kg]",\
 "nuScaleBOP_v1_1.LPTurbine.dew_in.h", 1, 5, 5674, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.h_fsat_out", "Saturated liquid specific enthalpy at outlet [J/kg]",\
 "nuScaleBOP_v1_1.LPTurbine.bubble_out.h", 1, 5, 5677, 0)
DeclareAlias2("nuScaleBOP_v1_1.LPTurbine.h_gsat_out", "Saturated vapor specific enthalpy  at outlet [J/kg]",\
 "nuScaleBOP_v1_1.LPTurbine.dew_out.h", 1, 5, 5680, 0)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.x_th_in", "Inlet thermodynamic quality [1]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.x_abs_in", "Inlet absolute mass quality [1]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.x_th_out", "Outlet thermodynamic quality [1]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.x_abs_out", "Outlet absolute mass quality [1]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.partialArc", "", 1.0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.LPTurbine.partialArc_nominal", \
"Nominal partial arc", 443, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.m_flow_nominal", "Nominal mass flowrate [kg/s]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.use_Stodola", "=true to use Stodola's law, i.e., infinite stages per unit [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareParameter("nuScaleBOP_v1_1.LPTurbine.Kt_constant", "Constant coefficient of Stodola's law [m2]",\
 444, 0.01, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.use_NominalInlet", "=true then Kt is calculated from nominal inlet conditions [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.p_inlet_nominal", "Nominal inlet pressure [Pa|bar]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.p_outlet_nominal", "Nominal outlet pressure [Pa|bar]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.use_T_nominal", "=true then use temperature for Kt else density [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.T_nominal", "Nominal inlet temperature [K|degC]",\
 288.15, 0.0,1E+100,300.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.d_nominal", "Nominal inlet density [kg/m3|g/cm3]",\
 0.0, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.LPTurbine.Kt", "Flow area coefficient [m2]", \
0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.Cond_Pump.use_input", "Use connector input for the mass flow [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareParameter("nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", "Nominal mass flowrate [kg/s]",\
 445, 54.940000000000005, -100000.0,100000.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.Cond_Pump.allowFlowReversal", "= true to allow flow reversal, false restricts to design direction [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.m_flow", "Mass flowrate [kg/s]", \
"nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", 1, 7, 445, 0)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.port_a.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", 1, 7, 445, 132)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.port_a.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.condenser.p", 1, 7, 447, 4)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.port_a.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 4)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.port_b.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", -1, 7, 445, 132)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.port_b.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 4)
DeclareVariable("nuScaleBOP_v1_1.Cond_Pump.port_b.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 100000.0, -10000000000.0,10000000000.0,500000.0,0,521)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump.m_flow_internal", "[kg/s]", \
"nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", 1, 7, 445, 1024)
DeclareParameter("nuScaleBOP_v1_1.condenser.showName", "[:#(type=Boolean)]", 446,\
 true, 0.0,0.0,0.0,0,562)
DeclareAlias2("nuScaleBOP_v1_1.condenser.port_a.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.LPTurbine.portHP.m_flow", 1, 5, 5636, 132)
DeclareAlias2("nuScaleBOP_v1_1.condenser.port_a.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.condenser.p", 1, 7, 447, 4)
DeclareAlias2("nuScaleBOP_v1_1.condenser.port_a.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.LPTurbine.state_b.h", 1, 5, 5654, 4)
DeclareAlias2("nuScaleBOP_v1_1.condenser.port_b.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", -1, 7, 445, 132)
DeclareAlias2("nuScaleBOP_v1_1.condenser.port_b.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.condenser.p", 1, 7, 447, 4)
DeclareAlias2("nuScaleBOP_v1_1.condenser.port_b.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.Cond_Pump.port_b.h_outflow", 1, 5, 5698, 4)
DeclareParameter("nuScaleBOP_v1_1.condenser.p", "Condenser operating pressure [Pa|kPa]",\
 447, 10000, 611.657,100000000.0,1000000.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.condenser.V_total", "Total volume (liquid + vapor) [m3]",\
 448, 10, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.condenser.massDynamics", "Formulation of mass balance [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.condenser.V_liquid_start", "Start value of the liquid volume [m3]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.condenser.set_m_flow", "=true to set port_b.m_flow = -port_a.m_flow [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareAlias2("nuScaleBOP_v1_1.condenser.sat.psat", "Saturation pressure [Pa|bar]",\
 "nuScaleBOP_v1_1.condenser.p", 1, 7, 447, 0)
DeclareVariable("nuScaleBOP_v1_1.condenser.sat.Tsat", "Saturation temperature [K|degC]",\
 500, 273.15,2273.15,500.0,0,513)
DeclareAlias2("nuScaleBOP_v1_1.condenser.h_fsat", "Specific enthalpy of saturated liquid [J/kg]",\
 "nuScaleBOP_v1_1.Cond_Pump.port_b.h_outflow", 1, 5, 5698, 0)
DeclareAlias2("nuScaleBOP_v1_1.condenser.h_gsat", "Specific enthalpy of saturated vapor [J/kg]",\
 "nuScaleBOP_v1_1.LPTurbine.state_b.h", 1, 5, 5654, 0)
DeclareVariable("nuScaleBOP_v1_1.condenser.rho_fsat", "Density of saturated liquid [kg/m3|g/cm3]",\
 0.0, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.condenser.rho_gsat", "Density of saturated steam [kg/m3|g/cm3]",\
 0.0, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.condenser.m_total", "Total mass, steam+liquid [kg]",\
 0.0, 0.0,1E+100,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.der(m_total)", "der(Total mass, steam+liquid) [kg/s]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.m_liquid", "Liquid mass [kg]", 0.0, \
0.0,1E+100,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.der(m_liquid)", "der(Liquid mass) [kg/s]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.m_vapor", "Steam mass [kg]", 0.0, 0.0,\
1E+100,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.der(m_vapor)", "der(Steam mass) [kg/s]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleBOP_v1_1.condenser.V_liquid", "Liquid volume [m3]", 51, 0.0,\
 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleBOP_v1_1.condenser.der(V_liquid)", "der(Liquid volume) [m3/s]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.V_vapor", "Steam volume [m3]", 0.0, \
0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.E", "Internal energy [J]", 0.0, \
0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.der(E)", "der(Internal energy) [W]", \
0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.condenser.Q_total", "Total thermal energy removed [W]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_1.m_flow", \
"Mass flow rate from the connection point into the component [kg/s]", \
"nuScaleBOP_v1_1.LPTurbine.portHP.m_flow", -1, 5, 5636, 132)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_1.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1, 1, 52, 4)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_1.h_outflow", \
"Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.h", 1, 1, 53, 4)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_2.m_flow", \
"Mass flow rate from the connection point into the component [kg/s]", \
"nuScaleModule_v5_1.port_a.m_flow", -1, 5, 5556, 132)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_2.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1, 1, 52, 4)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_2.h_outflow", \
"Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.h", 1, 1, 53, 4)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.port_3.m_flow", \
"Mass flow rate from the connection point into the component [kg/s]", 0.0, \
-100000.0,100000.0,0.0,0,776)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_3.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1, 1, 52, 4)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.port_3.h_outflow", \
"Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.h", 1, 1, 53, 4)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.portFlowDirection_1", \
"Flow direction for port_1 [:#(type=Modelica.Fluid.Types.PortFlowDirection)]", 3,\
 1.0,3.0,0.0,0,2565)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.portFlowDirection_2", \
"Flow direction for port_2 [:#(type=Modelica.Fluid.Types.PortFlowDirection)]", 3,\
 1.0,3.0,0.0,0,2565)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.portFlowDirection_3", \
"Flow direction for port_3 [:#(type=Modelica.Fluid.Types.PortFlowDirection)]", 3,\
 1.0,3.0,0.0,0,2565)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.fluidVolume", "Volume [m3]", \
"nuScaleBOP_v1_1.teeJunctionVolume.V", 1, 7, 453, 0)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.energyDynamics", \
"Formulation of energy balance [:#(type=Modelica.Fluid.Types.Dynamics)]", 1, 1.0,\
4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.massDynamics", \
"Formulation of mass balance [:#(type=Modelica.Fluid.Types.Dynamics)]", 1, 1.0,\
4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.substanceDynamics", \
"Formulation of substance balance [:#(type=Modelica.Fluid.Types.Dynamics)]", 1, \
1.0,4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.traceDynamics", \
"Formulation of trace substance balance [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleBOP_v1_1.teeJunctionVolume.p_start", "Start value of pressure [Pa|MPa]",\
 449, 1000000, 611.657,100000000.0,1000000.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.use_T_start", \
"= true, use T_start, otherwise h_start [:#(type=Boolean)]", false, 0.0,0.0,0.0,\
0,515)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.T_start", "Start value of temperature [K|degC]",\
 500, 273.15,2273.15,500.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.teeJunctionVolume.h_start", "Start value of specific enthalpy [J/kg]",\
 450, 2700000.0, -10000000000.0,10000000000.0,500000.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.teeJunctionVolume.X_start[1]", \
"Start value of mass fractions m_i/m [kg/kg]", 451, 1.0, 0.0,1.0,0.1,0,560)
DeclareState("nuScaleBOP_v1_1.teeJunctionVolume.medium.p", "Absolute pressure of medium [Pa|bar]",\
 52, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleBOP_v1_1.teeJunctionVolume.medium.der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleBOP_v1_1.teeJunctionVolume.medium.h", "Specific enthalpy of medium [J/kg]",\
 53, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleBOP_v1_1.teeJunctionVolume.medium.der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.d", "Density of medium [kg/m3|g/cm3]",\
 150, 0.0,100000.0,500.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.der(d)", \
"der(Density of medium) [Pa.m-2.s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.T", "Temperature of medium [K|degC]",\
 500.0, 273.15,2273.15,500.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 1, 0.0,2.0,0.0,0,644)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.medium.state.h", \
"Specific enthalpy [J/kg]", "nuScaleBOP_v1_1.teeJunctionVolume.medium.h", 1, 1, 53,\
 0)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.medium.state.d", \
"Density [kg/m3|g/cm3]", "nuScaleBOP_v1_1.teeJunctionVolume.medium.d", 1, 5, 5725,\
 0)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.medium.state.T", \
"Temperature [K|degC]", "nuScaleBOP_v1_1.teeJunctionVolume.medium.T", 1, 5, 5727,\
 0)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.medium.state.p", \
"Pressure [Pa|bar]", "nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1, 1, 52, 0)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.medium.sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1,\
 1, 52, 0)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.medium.sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.medium.phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.state.phase", 1, 5, 5733, 66)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.U", "Internal energy of fluid [J]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.der(U)", "der(Internal energy of fluid) [W]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.m", "Mass of fluid [kg]", 0.0,\
 0.0,1E+100,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.der(m)", "der(Mass of fluid) [kg/s]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.mb_flow", "Mass flows across boundaries [kg/s]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.der(m)", 1, 5, 5742, 0)
DeclareAlias2("nuScaleBOP_v1_1.teeJunctionVolume.Hb_flow", "Enthalpy flow across boundaries or energy source/sink [W]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.der(U)", 1, 5, 5740, 0)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.Qb_flow", "Heat flow across boundaries or energy source/sink [W]",\
 0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.teeJunctionVolume.Wb_flow", "Work flow across boundaries or source term [W]",\
 0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.teeJunctionVolume.initialize_p", \
"= true to set up initial equations for pressure [:#(type=Boolean)]", 452, true,\
 0.0,0.0,0.0,0,2610)
DeclareParameter("nuScaleBOP_v1_1.teeJunctionVolume.V", "Mixing volume inside junction [m3]",\
 453, 1, 0.0,0.0,0.0,0,560)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.port_a.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.port_3.m_flow", -1, 5, 5715, 132)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.port_a.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1, 1, 52, 4)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.port_a.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 4)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.port_b.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.port_3.m_flow", 1, 5, 5715, 132)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.port_b.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 4)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.port_b.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.medium.h", 1, 1, 53, 4)
DeclareVariable("nuScaleBOP_v1_1.Bleed.state.phase", "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 0, 0.0,2.0,0.0,0,517)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.state.h", "Specific enthalpy [J/kg]", \
"nuScaleBOP_v1_1.teeJunctionVolume.medium.h", 1, 1, 53, 0)
DeclareVariable("nuScaleBOP_v1_1.Bleed.state.d", "Density [kg/m3|g/cm3]", 100.0,\
 0.0,100000.0,500.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.Bleed.state.T", "Temperature [K|degC]", 500.0, \
273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.state.p", "Pressure [Pa|bar]", \
"nuScaleBOP_v1_1.teeJunctionVolume.medium.p", 1, 1, 52, 0)
DeclareVariable("nuScaleBOP_v1_1.Bleed.dp", "[Pa|bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.m_flow", "[kg/s]", "nuScaleBOP_v1_1.teeJunctionVolume.port_3.m_flow", -1,\
 5, 5715, 0)
DeclareParameter("nuScaleBOP_v1_1.Bleed.showName", "[:#(type=Boolean)]", 454, \
true, 0.0,0.0,0.0,0,562)
DeclareParameter("nuScaleBOP_v1_1.Bleed.showDP", "[:#(type=Boolean)]", 455, true,\
 0.0,0.0,0.0,0,562)
DeclareParameter("nuScaleBOP_v1_1.Bleed.precision", "Number of decimals displayed [:#(type=Integer)]",\
 456, 3, 0.0,1E+100,0.0,0,564)
DeclareVariable("nuScaleBOP_v1_1.Bleed.from_dp", "=true then m_flow is calculated from dp [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareParameter("nuScaleBOP_v1_1.Bleed.dp_nominal", "Nominal pressure drop [Pa|Pa]",\
 457, 10000.0, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.Bleed.m_flow_nominal", "Nominal mass flow rate [kg/s]",\
 458, 12.059999999999999, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.Bleed.deltax", "Interpolation interval near 0",\
 459, 0.01, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.Bleed.d_nominal", "Nominal density [kg/m3|g/cm3]",\
 0.0, 0.0,1E+100,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.Bleed.p_nominal", "Nominal inlet pressure [Pa|Pa]",\
 460, 1000000.0, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.Bleed.T_nominal", "Nominal inlet Temperature [K|degC]",\
 461, 726.15, 0.0,1E+100,300.0,0,560)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.d", "Inlet density [kg/m3|g/cm3]", \
"nuScaleBOP_v1_1.Bleed.state.d", 1, 5, 5746, 0)
DeclareAlias2("nuScaleBOP_v1_1.Bleed.T", "[K|degC]", "nuScaleBOP_v1_1.Bleed.state.T", 1,\
 5, 5747, 0)
DeclareVariable("nuScaleBOP_v1_1.OFWH.nPorts_a", "Number of port_a connections [:#(type=Integer)]",\
 1, 0.0,0.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.OFWH.nPorts_b", "Number of port_b connections [:#(type=Integer)]",\
 2, 0.0,0.0,0.0,0,517)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_a[1].m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump1.m_flow_nominal", -1, 7, 505, 132)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_a[1].p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 4)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_a[1].h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 4)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_b[1].m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump.m_flow_nominal", 1, 7, 445, 132)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_b[1].p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 4)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_b[1].h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 4)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_b[2].m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.teeJunctionVolume.port_3.m_flow", -1, 5, 5715, 132)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_b[2].p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 4)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.port_b[2].h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 4)
DeclareVariable("nuScaleBOP_v1_1.OFWH.V", "Volume [m3]", 1, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.energyDynamics", "Formulation of energy balances [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.OFWH.massDynamics", "Formulation of mass balances [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.OFWH.substanceDynamics", "Formulation of substance balances [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.OFWH.traceDynamics", "Formulation of trace substance balances [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleBOP_v1_1.OFWH.p_start", "Pressure [Pa|MPa]", 462, 1000000,\
 0.0,1E+100,100000.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.OFWH.use_T_start", "Use T_start if true, otherwise h_start [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.OFWH.T_start", "Temperature [K|degC]", 293.15, \
0.0,1E+100,300.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.h_start", "Specific enthalpy [J/kg]", 0.0,\
 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.OFWH.X_start[1]", "Mass fraction [1]", 463, \
1.0, 0.0,1.0,0.0,0,560)
DeclareState("nuScaleBOP_v1_1.OFWH.medium.p", "Absolute pressure of medium [Pa|bar]",\
 54, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleBOP_v1_1.OFWH.medium.der(p)", "der(Absolute pressure of medium) [Pa/s]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleBOP_v1_1.OFWH.medium.h", "Specific enthalpy of medium [J/kg]",\
 55, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleBOP_v1_1.OFWH.medium.der(h)", "der(Specific enthalpy of medium) [m2/s3]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleBOP_v1_1.OFWH.m", 1, 5, 5773, 0)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.T", "Temperature of medium [K|degC]",\
 500.0, 273.15,2273.15,500.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.der(u)", "der(Specific internal energy of medium) [m2/s3]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.state.phase", "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 1, 0.0,2.0,0.0,0,644)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.state.h", "Specific enthalpy [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 0)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.state.d", "Density [kg/m3|g/cm3]", \
"nuScaleBOP_v1_1.OFWH.m", 1, 5, 5773, 0)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.state.T", "Temperature [K|degC]", \
"nuScaleBOP_v1_1.OFWH.medium.T", 1, 5, 5761, 0)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.state.p", "Pressure [Pa|bar]", \
"nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 0)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.preferredMediumStates", \
"= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.standardOrderComponents", \
"If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.T_degC", "Temperature of medium in [degC] [degC;]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.p_bar", "Absolute pressure of medium in [bar] [bar]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.sat.psat", "Saturation pressure [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 0)
DeclareVariable("nuScaleBOP_v1_1.OFWH.medium.sat.Tsat", "Saturation temperature [K|degC]",\
 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.medium.phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleBOP_v1_1.OFWH.medium.state.phase", 1, 5, 5767, 66)
DeclareVariable("nuScaleBOP_v1_1.OFWH.m", "Mass [kg]", 0.0, 0.0,100000.0,500.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.der(m)", "der(Mass) [kg/s]", 0.0, 0.0,0.0,\
0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.U", "Internal energy [J]", 0.0, 0.0,0.0,\
0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.der(U)", "der(Internal energy) [W]", 0.0, \
0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.mb", "Mass flow rate source/sinks within volumes [kg/s]",\
 "nuScaleBOP_v1_1.OFWH.der(m)", 1, 5, 5774, 0)
DeclareAlias2("nuScaleBOP_v1_1.OFWH.Ub", "Energy source/sinks within volumes (e.g., ohmic heating, external convection) [W]",\
 "nuScaleBOP_v1_1.OFWH.der(U)", 1, 5, 5776, 0)
DeclareParameter("nuScaleBOP_v1_1.OFWH.initialize_p", "= true to set up initial equations for pressure [:#(type=Boolean)]",\
 464, true, 0.0,0.0,0.0,0,2610)
DeclareVariable("nuScaleBOP_v1_1.OFWH.geometry.V", "Volume [m3]", 1.0, 0.0,0.0,\
0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.geometry.angle", "Vertical angle from the horizontal (-pi/2 <= x <= pi/2) [rad|deg]",\
 0.0, -1.5807963267948966,1.5807963267948966,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.geometry.dheight", "Height(port_b) - Height(port_a) [m]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.geometry.height_a", "Elevation at port_a: Reference value only. No impact on calculations. [m]",\
 0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.geometry.height_b", "Elevation at port_b: Reference value only. No impact on calculations. [m]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.g_n", "Gravitational acceleration [m/s2]",\
 9.80665, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.H_flows_a[1]", "Enthalpy flow rates at port_a [W]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.H_flows_b[1]", "Enthalpy flow rates at port_b [W]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.H_flows_b[2]", "Enthalpy flow rates at port_b [W]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.OFWH.use_HeatPort", "=true to toggle heat port [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleBOP_v1_1.OFWH.Q_gen", "Internal heat generation [W]", 0,\
 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.OFWH.use_TraceMassPort", "=true to toggle trace mass port [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareParameter("nuScaleBOP_v1_1.OFWH.showName", "[:#(type=Boolean)]", 465, \
true, 0.0,0.0,0.0,0,562)
DeclareVariable("nuScaleBOP_v1_1.OFWH.Q_flow_internal", "[W]", 0, 0.0,0.0,0.0,0,2561)
DeclareParameter("nuScaleBOP_v1_1.generator.eta", "Mechanical to electric power conversion efficiency [1]",\
 466, 1.0, 0.0,1E+100,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.generator.J", "Moment of inertia [kg.m2]", 0, \
0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.generator.nPoles", "Number of electrical poles [:#(type=Integer)]",\
 467, 2, 0.0,0.0,0.0,0,564)
DeclareParameter("nuScaleBOP_v1_1.generator.f_start", "Start value of the electrical frequency [Hz]",\
 468, 60, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.generator.momentumDynamics", "Default formulation of momentum balances [:#(type=Modelica.Fluid.Types.Dynamics)]",\
 1, 1.0,4.0,0.0,0,517)
DeclareVariable("nuScaleBOP_v1_1.generator.Q_mech", "Mechanical power [W]", 0.0,\
 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.generator.Q_elec", "Electrical Power [W]", 0.0,\
 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleBOP_v1_1.generator.Q_loss", "Inertial power Loss [W]", 0,\
 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleBOP_v1_1.generator.tau", "Torque at shaft [N.m]", \
"nuScaleBOP_v1_1.LPTurbine.shaft_b.tau", -1, 5, 5640, 0)
DeclareAlias2("nuScaleBOP_v1_1.generator.omega_m", "Angular velocity of the shaft [rad/s]",\
 "nuScaleBOP_v1_1.HPTurbine.der(phi)", 1, 6, 50, 0)
DeclareVariable("nuScaleBOP_v1_1.generator.omega_e", "Angular velocity of the e.m.f. rotating frame [rad/s]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.generator.shaft_rpm", "Shaft rotational speed [rev/min]",\
 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleBOP_v1_1.generator.f", "Electrical frequency [Hz]", \
"nuScaleBOP_v1_1.boundary.f", 1, 7, 469, 0)
DeclareAlias2("nuScaleBOP_v1_1.generator.port.W", "Active power [W]", \
"nuScaleBOP_v1_1.generator.Q_elec", -1, 5, 5793, 132)
DeclareAlias2("nuScaleBOP_v1_1.generator.port.f", "Frequency [Hz]", \
"nuScaleBOP_v1_1.boundary.f", 1, 7, 469, 4)
DeclareAlias2("nuScaleBOP_v1_1.generator.shaft.phi", "Absolute rotation angle of flange [rad|deg]",\
 "nuScaleBOP_v1_1.HPTurbine.phi", 1, 1, 50, 4)
DeclareAlias2("nuScaleBOP_v1_1.generator.shaft.der(phi)", "der(Absolute rotation angle of flange) [rad/s]",\
 "nuScaleBOP_v1_1.HPTurbine.der(phi)", 1, 6, 50, 4)
DeclareAlias2("nuScaleBOP_v1_1.generator.shaft.tau", "Cut torque in the flange [N.m]",\
 "nuScaleBOP_v1_1.LPTurbine.shaft_b.tau", -1, 5, 5640, 132)
DeclareVariable("nuScaleBOP_v1_1.boundary.use_port", "= true to use input signal [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareParameter("nuScaleBOP_v1_1.boundary.f", "Frequency [Hz]", 469, 60, \
0.0,0.0,0.0,0,560)
DeclareAlias2("nuScaleBOP_v1_1.boundary.port.W", "Active power [W]", \
"nuScaleBOP_v1_1.generator.Q_elec", 1, 5, 5793, 132)
DeclareAlias2("nuScaleBOP_v1_1.boundary.port.f", "Frequency [Hz]", \
"nuScaleBOP_v1_1.boundary.f", 1, 7, 469, 4)
DeclareAlias2("nuScaleBOP_v1_1.boundary.f_internal", "[1/s]", "nuScaleBOP_v1_1.boundary.f", 1,\
 7, 469, 1024)
DeclareParameter("nuScaleBOP_v1_1.sensorW.precision", "Number of decimals displayed [:#(type=Integer)]",\
 470, 0, 0.0,1E+100,0.0,0,564)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.var", "Variable to be converted [W]", \
"nuScaleBOP_v1_1.generator.Q_elec", 1, 5, 5793, 0)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.y", "Icon display", "nuScaleBOP_v1_1.generator.Q_elec", 1,\
 5, 5793, 0)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.port_a.W", "Active power [W]", \
"nuScaleBOP_v1_1.generator.Q_elec", 1, 5, 5793, 132)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.port_a.f", "Frequency [Hz]", \
"nuScaleBOP_v1_1.boundary.f", 1, 7, 469, 4)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.port_b.W", "Active power [W]", \
"nuScaleBOP_v1_1.generator.Q_elec", -1, 5, 5793, 132)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.port_b.f", "Frequency [Hz]", \
"nuScaleBOP_v1_1.boundary.f", 1, 7, 469, 4)
DeclareAlias2("nuScaleBOP_v1_1.sensorW.W", "Power flowing from port_a to port_b [W]",\
 "nuScaleBOP_v1_1.generator.Q_elec", 1, 5, 5793, 0)
DeclareParameter("nuScaleBOP_v1_1.data.nModules", "", 471, 12, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.Q_total", "Total thermal output [W]", 472,\
 160000000.0, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.Q_total_el", "Total electrical output [W]",\
 473, 45000000.0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.eta", "Net efficiency [1]", 0.0, 0.0,0.0,\
0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.p", "[Pa|bar]", 474, 12760000.0, 0.0,0.0,\
0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.T_hot", "estimate [K|degC]", 475, 598.15,\
 0.0,1E+100,300.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.T_cold", "[K|degC]", 288.15, 0.0,1E+100,\
300.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.T_avg", "[K|degC]", 288.15, 0.0,1E+100,\
300.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.dT_core", "[K,]", 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.h_hot", "[J/kg]", 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.h_cold", "[J/kg]", 0.0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.m_flow", "rough estimate from normalizing IRIS and rounded down [kg/s]",\
 476, 700, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.d_reactorVessel_outer", "[m]", 477, 2.75,\
 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.length_reactorVessel", "[m]", 478, 20, \
0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.length_inletPlenum", "[m]", 479, 2, \
0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.d_inletPlenum", "[m]", 0.0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.length_core", "[m]", 480, 2.408, 0.0,0.0,\
0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.d_core", "[m]", 481, 1.5, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.r_outer_fuelRod", "Outside diameter of fuel rod (d3s1) [m]",\
 482, 0.004572, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.th_clad_fuelRod", "Cladding thickness of fuel rod (d3s1) [m]",\
 483, 0.0005715, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.th_gap_fuelRod", "Gap thickness between pellet and cladding (d3s1) [m]",\
 484, 7.874E-05, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.r_pellet_fuelRod", "Pellet radius (d3s1) [m]",\
 485, 0.00392176, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.pitch_fuelRod", "Fuel rod pitch (d3s1) [m]",\
 486, 0.0125984, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.sizeAssembly", "square size of assembly (e.g., 17 = 17x17) [1]",\
 487, 17, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.nRodFuel_assembly", "# of fuel rods per assembly (d3s1) [1]",\
 488, 264, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.nRodNonFuel_assembly", "# of non-fuel rods per assembly (d3s1) [1]",\
 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.nAssembly", "[1]", 0.0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.length_outletPlenum", "[m]", 489, 3, \
0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.d_outletPlenum", "[m]", 490, 2, 0.0,0.0,\
0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.length_hotLeg", "[m]", 491, 10.092, \
0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.d_hotLeg", "[m]", 492, 1.4, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.length_pressurizer", "[m]", 493, 2.5, \
0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.d_pressurizer", "[m]", 0.0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.length_steamGenerator", "[m]", 494, 5.5, \
0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.d_steamGenerator_tube_outer", "[m]", 495,\
 0.0127, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.th_steamGenerator_tube", "Sch 10/20 [m]",\
 496, 0.0021082, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.d_steamGenerator_tube_inner", "[m]", 0.0, \
0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.d_steamGenerator_shell_inner", "[m]", 0.0,\
 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.d_steamGenerator_shell_outer", "[m]", 0.0,\
 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.ratioPD_steamGenerator_tube", \
"pitch to diameter ratio", 497, 1.5, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.nPasses", "", 498, 2, 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.nEntryPoint_steamGenerator", "", 499, 128,\
 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.nTubes_steamGenerator_perEntryPoint", "", \
0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.nTubes_steamGenerator", "", 0.0, 0.0,0.0,\
0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.length_steamGenerator_tube", "[m]", 500, 36,\
 0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.length_coldLeg", "[m]", 501, 12, 0.0,0.0,\
0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.d_coldLeg_inner", "[m]", 0.0, 0.0,0.0,0.0,\
0,513)
DeclareVariable("nuScaleBOP_v1_1.data.d_coldLeg_outer", "[m]", 0.0, 0.0,0.0,0.0,\
0,513)
DeclareVariable("nuScaleBOP_v1_1.data.d_coldLeg", "[m]", 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.lengths[1]", "[m]", 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.lengths[2]", "[m]", 0.0, 0.0,0.0,0.0,0,513)
DeclareParameter("nuScaleBOP_v1_1.data.p_steam", "[Pa|bar]", 502, 3500000.0, \
0.0,0.0,0.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.T_steam_hot", "[K|degC]", 503, 573.15, \
0.0,1E+100,300.0,0,560)
DeclareParameter("nuScaleBOP_v1_1.data.T_steam_cold", "[K|degC]", 504, 473.15, \
0.0,1E+100,300.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.data.h_steam_hot", "[J/kg]", 0.0, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleBOP_v1_1.data.h_steam_cold", "[J/kg]", 0.0, 0.0,0.0,0.0,\
0,513)
DeclareVariable("nuScaleBOP_v1_1.data.m_flow_steam", "[kg/s]", 0.0, 0.0,0.0,0.0,\
0,513)
DeclareVariable("nuScaleBOP_v1_1.Cond_Pump1.use_input", "Use connector input for the mass flow [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareParameter("nuScaleBOP_v1_1.Cond_Pump1.m_flow_nominal", "Nominal mass flowrate [kg/s]",\
 505, 67, 0.0,100000.0,0.0,0,560)
DeclareVariable("nuScaleBOP_v1_1.Cond_Pump1.allowFlowReversal", "= true to allow flow reversal, false restricts to design direction [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.m_flow", "Mass flowrate [kg/s]", \
"nuScaleBOP_v1_1.Cond_Pump1.m_flow_nominal", 1, 7, 505, 0)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.port_a.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump1.m_flow_nominal", 1, 7, 505, 132)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.port_a.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleBOP_v1_1.OFWH.medium.p", 1, 1, 54, 4)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.port_a.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleModule_v5_1.STHX.tube.mediums[1].h", 1, 1, 98, 4)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.port_b.m_flow", "Mass flow rate from the connection point into the component [kg/s]",\
 "nuScaleBOP_v1_1.Cond_Pump1.m_flow_nominal", -1, 7, 505, 132)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.port_b.p", "Thermodynamic pressure in the connection point [Pa|bar]",\
 "nuScaleModule_v5_1.STHX.tube.mediums[1].p", 1, 1, 97, 4)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.port_b.h_outflow", "Specific thermodynamic enthalpy close to the connection point if m_flow < 0 [J/kg]",\
 "nuScaleBOP_v1_1.OFWH.medium.h", 1, 1, 55, 4)
DeclareAlias2("nuScaleBOP_v1_1.Cond_Pump1.m_flow_internal", "[kg/s]", \
"nuScaleBOP_v1_1.Cond_Pump1.m_flow_nominal", 1, 7, 505, 1024)
DeclareState("nuScaleModule_v5_1.Lower_Riser.mediums[1].p", "Absolute pressure of medium [Pa|bar]",\
 56, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Lower_Riser.mediums[1].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.Lower_Riser.mediums[1].h", "Specific enthalpy of medium [J/kg]",\
 57, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Lower_Riser.mediums[1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.Lower_Riser.statesFM[1].d", 1, 5, 99, 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.Lower_Riser.statesFM[1].T", 1, 5, 101, 0)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.Lower_Riser.statesFM[1].phase", 1, 5, 98, 66)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].h", 1, 1,\
 57, 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.Lower_Riser.statesFM[1].d", 1, 5, 99,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.Lower_Riser.statesFM[1].T", 1, 5, 101,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].p", 1, 1, 56, 0)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].p", 1,\
 1, 56, 0)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[1].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[1].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.Lower_Riser.statesFM[1].phase", 1, 5, 98, 66)
DeclareState("nuScaleModule_v5_1.Lower_Riser.mediums[2].p", "Absolute pressure of medium [Pa|bar]",\
 58, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Lower_Riser.mediums[2].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,576)
DeclareState("nuScaleModule_v5_1.Lower_Riser.mediums[2].h", "Specific enthalpy of medium [J/kg]",\
 59, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Lower_Riser.mediums[2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.Lower_Riser.statesFM[2].d", 1, 5, 103, 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.Lower_Riser.statesFM[2].T", 1, 5, 105, 0)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.Lower_Riser.statesFM[2].phase", 1, 5, 102, 66)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.Lower_Riser.mediums[2].h", 1, 1,\
 59, 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.Lower_Riser.statesFM[2].d", 1, 5, 103,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.Lower_Riser.statesFM[2].T", 1, 5, 105,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[2].p", 1, 1, 58, 0)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[2].p", 1,\
 1, 58, 0)
DeclareVariable("nuScaleModule_v5_1.Lower_Riser.mediums[2].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Lower_Riser.mediums[2].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.Lower_Riser.statesFM[2].phase", 1, 5, 102, 66)
DeclareState("nuScaleModule_v5_1.DownComer.mediums[1].p", "Absolute pressure of medium [Pa|bar]",\
 60, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.DownComer.mediums[1].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,576)
DeclareState("nuScaleModule_v5_1.DownComer.mediums[1].h", "Specific enthalpy of medium [J/kg]",\
 61, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.DownComer.mediums[1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.DownComer.statesFM[1].d", 1, 5, 233, 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.DownComer.statesFM[1].T", 1, 5, 235, 0)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.DownComer.statesFM[1].phase", 1, 5, 232, 66)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.DownComer.mediums[1].h", 1, 1, 61,\
 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.DownComer.statesFM[1].d", 1, 5, 233,\
 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.DownComer.statesFM[1].T", 1, 5, 235,\
 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1, 60, 0)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1,\
 60, 0)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[1].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[1].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.DownComer.statesFM[1].phase", 1, 5, 232, 66)
DeclareState("nuScaleModule_v5_1.DownComer.mediums[2].p", "Absolute pressure of medium [Pa|bar]",\
 62, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.DownComer.mediums[2].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.DownComer.mediums[2].h", "Specific enthalpy of medium [J/kg]",\
 63, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.DownComer.mediums[2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.DownComer.statesFM[2].d", 1, 5, 237, 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.DownComer.statesFM[2].T", 1, 5, 239, 0)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.DownComer.statesFM[2].phase", 1, 5, 236, 66)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.DownComer.mediums[2].h", 1, 1, 63,\
 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.DownComer.statesFM[2].d", 1, 5, 237,\
 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.DownComer.statesFM[2].T", 1, 5, 239,\
 0)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[2].p", 1, 1, 62, 0)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[2].p", 1, 1,\
 62, 0)
DeclareVariable("nuScaleModule_v5_1.DownComer.mediums[2].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.DownComer.mediums[2].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.DownComer.statesFM[2].phase", 1, 5, 236, 66)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].p", "Absolute pressure of medium [Pa|bar]",\
 "nuScaleModule_v5_1.Lower_Riser.mediums[2].p", 1, 1, 58, 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", "nuScaleModule_v5_1.Lower_Riser.mediums[2].der(p)", 1,\
 6, 58, 0)
DeclareState("nuScaleModule_v5_1.Upper_Riser.mediums[1].h", "Specific enthalpy of medium [J/kg]",\
 64, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Upper_Riser.mediums[1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.Upper_Riser.statesFM[1].d", 1, 5, 366, 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.Upper_Riser.statesFM[1].T", 1, 5, 368, 0)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.Upper_Riser.statesFM[1].phase", 1, 5, 365, 66)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.Upper_Riser.mediums[1].h", 1, 1,\
 64, 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.Upper_Riser.statesFM[1].d", 1, 5, 366,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.Upper_Riser.statesFM[1].T", 1, 5, 368,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[2].p", 1, 1, 58, 0)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[2].p", 1,\
 1, 58, 0)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[1].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[1].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.Upper_Riser.statesFM[1].phase", 1, 5, 365, 66)
DeclareState("nuScaleModule_v5_1.Upper_Riser.mediums[2].p", "Absolute pressure of medium [Pa|bar]",\
 65, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Upper_Riser.mediums[2].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,576)
DeclareState("nuScaleModule_v5_1.Upper_Riser.mediums[2].h", "Specific enthalpy of medium [J/kg]",\
 66, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.Upper_Riser.mediums[2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.Upper_Riser.statesFM[2].d", 1, 5, 370, 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.Upper_Riser.statesFM[2].T", 1, 5, 372, 0)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.Upper_Riser.statesFM[2].phase", 1, 5, 369, 66)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].h", 1, 1,\
 66, 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.Upper_Riser.statesFM[2].d", 1, 5, 370,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.Upper_Riser.statesFM[2].T", 1, 5, 372,\
 0)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].p", 1, 1, 65, 0)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].p", 1,\
 1, 65, 0)
DeclareVariable("nuScaleModule_v5_1.Upper_Riser.mediums[2].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.Upper_Riser.mediums[2].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.Upper_Riser.statesFM[2].phase", 1, 5, 369, 66)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].p", \
"Absolute pressure of medium [Pa|bar]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].p", 1,\
 1, 65, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].der(p)", 1,\
 6, 65, 0)
DeclareState("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].h", \
"Specific enthalpy of medium [J/kg]", 67, 0.0, -10000000000.0,10000000000.0,\
500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].d", \
"Density of medium [kg/m3|g/cm3]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[1].d", 1,\
 5, 506, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].T", \
"Temperature of medium [K|degC]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[1].T", 1,\
 5, 508, 0)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].u", \
"Specific internal energy of medium [J/kg]", 0.0, -100000000.0,100000000.0,\
1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.018015268, 0.001,0.25,\
0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.PressurizerandTopper.statesFM[1].phase", 1, 5, 505, 66)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.PressurizerandTopper.mediums[1].h", 1,\
 1, 67, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[1].d", 1,\
 5, 506, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[1].T", 1,\
 5, 508, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].p", 1, 1, 65, 0)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.Upper_Riser.mediums[2].p", 1,\
 1, 65, 0)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[1].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.PressurizerandTopper.statesFM[1].phase", 1, 5, 505, 66)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].p", \
"Absolute pressure of medium [Pa|bar]", "nuScaleModule_v5_1.pressurizer_tee.medium.p", 1,\
 1, 2, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", "nuScaleModule_v5_1.pressurizer_tee.medium.der(p)", 1,\
 6, 2, 0)
DeclareState("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].h", \
"Specific enthalpy of medium [J/kg]", 68, 0.0, -10000000000.0,10000000000.0,\
500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].d", \
"Density of medium [kg/m3|g/cm3]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[2].d", 1,\
 5, 510, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].T", \
"Temperature of medium [K|degC]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[2].T", 1,\
 5, 512, 0)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].u", \
"Specific internal energy of medium [J/kg]", 0.0, -100000000.0,100000000.0,\
1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.018015268, 0.001,0.25,\
0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.PressurizerandTopper.statesFM[2].phase", 1, 5, 509, 66)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.PressurizerandTopper.mediums[2].h", 1,\
 1, 68, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[2].d", 1,\
 5, 510, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.PressurizerandTopper.statesFM[2].T", 1,\
 5, 512, 0)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.pressurizer_tee.medium.p", 1, 1, 2, 0)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.pressurizer_tee.medium.p", 1,\
 1, 2, 0)
DeclareVariable("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.PressurizerandTopper.mediums[2].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.PressurizerandTopper.statesFM[2].phase", 1, 5, 509, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[1].p", "Absolute pressure of medium [Pa|bar]",\
 69, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[1].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[1].h", "Specific enthalpy of medium [J/kg]",\
 70, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[1].d", 1, 5, 1767, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[1].T", 1, 5, 1769, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[1].phase", 1, 5, 1766, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[1].h", 1, 1, 70,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].d", 1, 5, 1767,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].T", 1, 5, 1769,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[1].p", 1, 1, 69, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[1].p", 1,\
 1, 69, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[1].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[1].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[1].phase", 1, 5, 1766, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[2].p", "Absolute pressure of medium [Pa|bar]",\
 71, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[2].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[2].h", "Specific enthalpy of medium [J/kg]",\
 72, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1, 5, 1771, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[2].T", 1, 5, 1773, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[2].phase", 1, 5, 1770, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[2].h", 1, 1, 72,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1, 5, 1771,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].T", 1, 5, 1773,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[2].p", 1, 1, 71, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[2].p", 1,\
 1, 71, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[2].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[2].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[2].phase", 1, 5, 1770, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[3].p", "Absolute pressure of medium [Pa|bar]",\
 73, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[3].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[3].h", "Specific enthalpy of medium [J/kg]",\
 74, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[3].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1, 5, 1775, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[3].T", 1, 5, 1777, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[3].phase", 1, 5, 1774, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[3].h", 1, 1, 74,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1, 5, 1775,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].T", 1, 5, 1777,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[3].p", 1, 1, 73, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[3].p", 1,\
 1, 73, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[3].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[3].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[3].phase", 1, 5, 1774, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[4].p", "Absolute pressure of medium [Pa|bar]",\
 75, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[4].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[4].h", "Specific enthalpy of medium [J/kg]",\
 76, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[4].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1, 5, 1779, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[4].T", 1, 5, 1781, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[4].phase", 1, 5, 1778, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[4].h", 1, 1, 76,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1, 5, 1779,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].T", 1, 5, 1781,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[4].p", 1, 1, 75, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[4].p", 1,\
 1, 75, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[4].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[4].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[4].phase", 1, 5, 1778, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[5].p", "Absolute pressure of medium [Pa|bar]",\
 77, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[5].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[5].h", "Specific enthalpy of medium [J/kg]",\
 78, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[5].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1, 5, 1783, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[5].T", 1, 5, 1785, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[5].phase", 1, 5, 1782, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[5].h", 1, 1, 78,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1, 5, 1783,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].T", 1, 5, 1785,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[5].p", 1, 1, 77, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[5].p", 1,\
 1, 77, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[5].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[5].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[5].phase", 1, 5, 1782, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[6].p", "Absolute pressure of medium [Pa|bar]",\
 79, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[6].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[6].h", "Specific enthalpy of medium [J/kg]",\
 80, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[6].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1, 5, 1787, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[6].T", 1, 5, 1789, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[6].phase", 1, 5, 1786, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[6].h", 1, 1, 80,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1, 5, 1787,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].T", 1, 5, 1789,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[6].p", 1, 1, 79, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[6].p", 1,\
 1, 79, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[6].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[6].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[6].phase", 1, 5, 1786, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[7].p", "Absolute pressure of medium [Pa|bar]",\
 81, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[7].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[7].h", "Specific enthalpy of medium [J/kg]",\
 82, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[7].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1, 5, 1791, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[7].T", 1, 5, 1793, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[7].phase", 1, 5, 1790, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[7].h", 1, 1, 82,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1, 5, 1791,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].T", 1, 5, 1793,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[7].p", 1, 1, 81, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[7].p", 1,\
 1, 81, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[7].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[7].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[7].phase", 1, 5, 1790, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[8].p", "Absolute pressure of medium [Pa|bar]",\
 83, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[8].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[8].h", "Specific enthalpy of medium [J/kg]",\
 84, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[8].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1, 5, 1795, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[8].T", 1, 5, 1797, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[8].phase", 1, 5, 1794, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[8].h", 1, 1, 84,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1, 5, 1795,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].T", 1, 5, 1797,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[8].p", 1, 1, 83, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[8].p", 1,\
 1, 83, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[8].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[8].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[8].phase", 1, 5, 1794, 66)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[9].p", "Absolute pressure of medium [Pa|bar]",\
 85, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[9].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[9].h", "Specific enthalpy of medium [J/kg]",\
 86, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[9].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1, 5, 1799, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[9].T", 1, 5, 1801, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[9].phase", 1, 5, 1798, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[9].h", 1, 1, 86,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1, 5, 1799,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].T", 1, 5, 1801,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[9].p", 1, 1, 85, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[9].p", 1,\
 1, 85, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[9].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[9].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[9].phase", 1, 5, 1798, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].p", "Absolute pressure of medium [Pa|bar]",\
 "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1, 60, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", "nuScaleModule_v5_1.DownComer.mediums[1].der(p)", 1,\
 6, 60, 0)
DeclareState("nuScaleModule_v5_1.STHX.shell.mediums[10].h", "Specific enthalpy of medium [J/kg]",\
 87, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.mediums[10].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,576)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[10].d", 1, 5, 1803, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[10].T", 1, 5, 1805, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[10].phase", 1, 5, 1802, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[10].h", 1, 1,\
 87, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].d", 1, 5, 1803,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].T", 1, 5, 1805,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1, 60, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1,\
 60, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.mediums[10].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.mediums[10].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.STHX.shell.statesFM[10].phase", 1, 5, 1802, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[1].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[1].phase", 1, 5, 1766, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[1].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[1].h", 1, 1, 70,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[1].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].d", 1, 5, 1767,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[1].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].T", 1, 5, 1769,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[1].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[1].p", 1, 1, 69, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[2].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[2].phase", 1, 5, 1770, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[2].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[2].h", 1, 1, 72,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[2].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1, 5, 1771,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[2].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].T", 1, 5, 1773,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[2].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[2].p", 1, 1, 71, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[3].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[3].phase", 1, 5, 1774, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[3].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[3].h", 1, 1, 74,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[3].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1, 5, 1775,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[3].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].T", 1, 5, 1777,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[3].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[3].p", 1, 1, 73, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[4].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[4].phase", 1, 5, 1778, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[4].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[4].h", 1, 1, 76,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[4].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1, 5, 1779,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[4].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].T", 1, 5, 1781,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[4].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[4].p", 1, 1, 75, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[5].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[5].phase", 1, 5, 1782, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[5].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[5].h", 1, 1, 78,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[5].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1, 5, 1783,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[5].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].T", 1, 5, 1785,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[5].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[5].p", 1, 1, 77, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[6].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[6].phase", 1, 5, 1786, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[6].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[6].h", 1, 1, 80,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[6].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1, 5, 1787,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[6].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].T", 1, 5, 1789,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[6].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[6].p", 1, 1, 79, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[7].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[7].phase", 1, 5, 1790, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[7].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[7].h", 1, 1, 82,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[7].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1, 5, 1791,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[7].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].T", 1, 5, 1793,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[7].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[7].p", 1, 1, 81, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[8].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[8].phase", 1, 5, 1794, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[8].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[8].h", 1, 1, 84,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[8].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1, 5, 1795,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[8].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].T", 1, 5, 1797,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[8].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[8].p", 1, 1, 83, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[9].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[9].phase", 1, 5, 1798, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[9].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[9].h", 1, 1, 86,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[9].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1, 5, 1799,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[9].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].T", 1, 5, 1801,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[9].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[9].p", 1, 1, 85, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[10].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[10].phase", 1, 5, 1802, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[10].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[10].h", 1, 1,\
 87, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[10].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].d", 1, 5, 1803,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].T", 1, 5, 1805,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.states[10].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1, 60, 0)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].k",\
 "Gain [1]", 506, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].y_start",\
 "Initial or guess value of output (= state)", 507, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].y", \
"Connector of Real output signal", 88, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[1].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].k",\
 "Gain [1]", 508, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].y_start",\
 "Initial or guess value of output (= state)", 509, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].y", \
"Connector of Real output signal", 89, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[2].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].k",\
 "Gain [1]", 510, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].y_start",\
 "Initial or guess value of output (= state)", 511, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].y", \
"Connector of Real output signal", 90, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[3].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].k",\
 "Gain [1]", 512, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].y_start",\
 "Initial or guess value of output (= state)", 513, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].y", \
"Connector of Real output signal", 91, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[4].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].k",\
 "Gain [1]", 514, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].y_start",\
 "Initial or guess value of output (= state)", 515, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].y", \
"Connector of Real output signal", 92, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[5].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].k",\
 "Gain [1]", 516, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].y_start",\
 "Initial or guess value of output (= state)", 517, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].y", \
"Connector of Real output signal", 93, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[6].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].k",\
 "Gain [1]", 518, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].y_start",\
 "Initial or guess value of output (= state)", 519, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].y", \
"Connector of Real output signal", 94, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[7].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].k",\
 "Gain [1]", 520, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].y_start",\
 "Initial or guess value of output (= state)", 521, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].y", \
"Connector of Real output signal", 95, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[8].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].k",\
 "Gain [1]", 522, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].y_start",\
 "Initial or guess value of output (= state)", 523, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].y", \
"Connector of Real output signal", 96, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.shell.flowModel.firstOrder_dps_K[9].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[1].phase", 1, 5, 1766, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[1].h", 1, 1, 70,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].d", 1, 5, 1767,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].T", 1, 5, 1769,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[1].p", 1, 1, 69, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[1].h", 1,\
 1, 70, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].d", 1,\
 5, 1767, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].T", 1, 5,\
 1769, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[1].p", 1, 1, 69,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[1]", 1,\
 5, 1262, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[1].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[2].phase", 1, 5, 1770, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[2].h", 1, 1, 72,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1, 5, 1771,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].T", 1, 5, 1773,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[2].p", 1, 1, 71, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[2].h", 1,\
 1, 72, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1,\
 5, 1771, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].T", 1, 5,\
 1773, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[2].p", 1, 1, 71,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[2]", 1,\
 5, 1263, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[2].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[3].phase", 1, 5, 1774, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[3].h", 1, 1, 74,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1, 5, 1775,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].T", 1, 5, 1777,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[3].p", 1, 1, 73, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[3].h", 1,\
 1, 74, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1,\
 5, 1775, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].T", 1, 5,\
 1777, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[3].p", 1, 1, 73,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[3]", 1,\
 5, 1264, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[3].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[4].phase", 1, 5, 1778, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[4].h", 1, 1, 76,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1, 5, 1779,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].T", 1, 5, 1781,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[4].p", 1, 1, 75, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[4].h", 1,\
 1, 76, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1,\
 5, 1779, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].T", 1, 5,\
 1781, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[4].p", 1, 1, 75,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[4]", 1,\
 5, 1265, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[4].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[5].phase", 1, 5, 1782, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[5].h", 1, 1, 78,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1, 5, 1783,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].T", 1, 5, 1785,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[5].p", 1, 1, 77, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[5].h", 1,\
 1, 78, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1,\
 5, 1783, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].T", 1, 5,\
 1785, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[5].p", 1, 1, 77,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[5]", 1,\
 5, 1266, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[5].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[6].phase", 1, 5, 1786, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[6].h", 1, 1, 80,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1, 5, 1787,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].T", 1, 5, 1789,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[6].p", 1, 1, 79, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[6].h", 1,\
 1, 80, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1,\
 5, 1787, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].T", 1, 5,\
 1789, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[6].p", 1, 1, 79,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[6]", 1,\
 5, 1267, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[6].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[7].phase", 1, 5, 1790, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[7].h", 1, 1, 82,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1, 5, 1791,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].T", 1, 5, 1793,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[7].p", 1, 1, 81, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[7].h", 1,\
 1, 82, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1,\
 5, 1791, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].T", 1, 5,\
 1793, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[7].p", 1, 1, 81,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[7]", 1,\
 5, 1268, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[7].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[8].phase", 1, 5, 1794, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[8].h", 1, 1, 84,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1, 5, 1795,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].T", 1, 5, 1797,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[8].p", 1, 1, 83, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[8].h", 1,\
 1, 84, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1,\
 5, 1795, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].T", 1, 5,\
 1797, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[8].p", 1, 1, 83,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[8]", 1,\
 5, 1269, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[8].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[9].phase", 1, 5, 1798, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[9].h", 1, 1, 86,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1, 5, 1799,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].T", 1, 5, 1801,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[9].p", 1, 1, 85, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[9].h", 1,\
 1, 86, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1,\
 5, 1799, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].T", 1, 5,\
 1801, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.shell.mediums[9].p", 1, 1, 85,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[9]", 1,\
 5, 1270, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[9].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.shell.statesFM[10].phase", 1, 5, 1802, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[10].h", 1, 1,\
 87, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].d", 1, 5, 1803,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].T", 1, 5, 1805,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1, 60, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.shell.mediums[10].h", 1,\
 1, 87, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].d", 1,\
 5, 1803, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].T", 1,\
 5, 1805, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[1].p", 1, 1, 60,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_b[9]", 1,\
 5, 1271, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.mediaProps[10].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[1]", 1, 5, 1806,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[1].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[2]", 1, 5, 1807,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[2].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[3]", 1, 5, 1808,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[3].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[4]", 1, 5, 1809,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[4].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[5]", 1, 5, 1810,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[5].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[6]", 1, 5, 1811,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[6].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[7]", 1, 5, 1812,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[7].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[8]", 1, 5, 1813,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[8].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.STHX.geometry.dimensions_shell[1]", 1,\
 5, 630, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_shell[1]", 1,\
 5, 631, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.shell.dlengthsFM[9]", 1, 5, 1814,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.shell.flowModel.IN_con[9].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[1].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[1].d", 1,\
 5, 1767, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[1].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1,\
 5, 1771, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[1].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[1]", 1,\
 5, 1262, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[1].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[2]", 1,\
 5, 1263, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[2].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[2].d", 1,\
 5, 1771, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[2].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1,\
 5, 1775, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[2].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[2]", 1,\
 5, 1263, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[2].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[3]", 1,\
 5, 1264, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[3].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[3].d", 1,\
 5, 1775, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[3].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1,\
 5, 1779, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[3].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[3]", 1,\
 5, 1264, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[3].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[4]", 1,\
 5, 1265, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[4].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[4].d", 1,\
 5, 1779, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[4].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1,\
 5, 1783, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[4].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[4]", 1,\
 5, 1265, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[4].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[5]", 1,\
 5, 1266, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[5].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[5].d", 1,\
 5, 1783, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[5].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1,\
 5, 1787, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[5].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[5]", 1,\
 5, 1266, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[5].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[6]", 1,\
 5, 1267, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[6].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[6].d", 1,\
 5, 1787, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[6].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1,\
 5, 1791, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[6].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[6]", 1,\
 5, 1267, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[6].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[7]", 1,\
 5, 1268, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[7].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[7].d", 1,\
 5, 1791, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[7].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1,\
 5, 1795, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[7].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[7]", 1,\
 5, 1268, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[7].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[8]", 1,\
 5, 1269, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[8].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[8].d", 1,\
 5, 1795, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[8].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1,\
 5, 1799, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[8].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[8]", 1,\
 5, 1269, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[8].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[9]", 1,\
 5, 1270, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[9].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[9].d", 1,\
 5, 1799, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[9].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.shell.statesFM[10].d", 1,\
 5, 1803, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[9].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_a[9]", 1,\
 5, 1270, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.shell.flowModel.IN_var[9].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.shell.flowModel.mus_b[9]", 1,\
 5, 1271, 0)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[1].p", "Absolute pressure of medium [Pa|bar]",\
 97, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[1].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[1].h", "Specific enthalpy of medium [J/kg]",\
 98, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[1].d", 1, 5, 2963, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[1].T", 1, 5, 2965, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[1].phase", 1, 5, 2962, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[1].h", 1, 1, 98,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].d", 1, 5, 2963,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].T", 1, 5, 2965,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[1].p", 1, 1, 97, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[1].p", 1, 1,\
 97, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[1].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[1].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[1].phase", 1, 5, 2962, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[2].p", "Absolute pressure of medium [Pa|bar]",\
 99, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[2].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[2].h", "Specific enthalpy of medium [J/kg]",\
 100, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1, 5, 2967, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[2].T", 1, 5, 2969, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[2].phase", 1, 5, 2966, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[2].h", 1, 1, 100,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1, 5, 2967,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].T", 1, 5, 2969,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[2].p", 1, 1, 99, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[2].p", 1, 1,\
 99, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[2].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[2].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[2].phase", 1, 5, 2966, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[3].p", "Absolute pressure of medium [Pa|bar]",\
 101, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[3].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[3].h", "Specific enthalpy of medium [J/kg]",\
 102, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[3].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1, 5, 2971, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[3].T", 1, 5, 2973, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[3].phase", 1, 5, 2970, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[3].h", 1, 1, 102,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1, 5, 2971,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].T", 1, 5, 2973,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[3].p", 1, 1, 101, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[3].p", 1, 1,\
 101, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[3].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[3].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[3].phase", 1, 5, 2970, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[4].p", "Absolute pressure of medium [Pa|bar]",\
 103, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[4].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[4].h", "Specific enthalpy of medium [J/kg]",\
 104, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[4].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1, 5, 2975, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[4].T", 1, 5, 2977, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[4].phase", 1, 5, 2974, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[4].h", 1, 1, 104,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1, 5, 2975,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].T", 1, 5, 2977,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[4].p", 1, 1, 103, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[4].p", 1, 1,\
 103, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[4].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[4].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[4].phase", 1, 5, 2974, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[5].p", "Absolute pressure of medium [Pa|bar]",\
 105, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[5].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[5].h", "Specific enthalpy of medium [J/kg]",\
 106, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[5].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1, 5, 2979, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[5].T", 1, 5, 2981, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[5].phase", 1, 5, 2978, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[5].h", 1, 1, 106,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1, 5, 2979,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].T", 1, 5, 2981,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[5].p", 1, 1, 105, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[5].p", 1, 1,\
 105, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[5].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[5].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[5].phase", 1, 5, 2978, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[6].p", "Absolute pressure of medium [Pa|bar]",\
 107, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[6].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[6].h", "Specific enthalpy of medium [J/kg]",\
 108, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[6].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1, 5, 2983, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[6].T", 1, 5, 2985, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[6].phase", 1, 5, 2982, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[6].h", 1, 1, 108,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1, 5, 2983,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].T", 1, 5, 2985,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[6].p", 1, 1, 107, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[6].p", 1, 1,\
 107, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[6].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[6].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[6].phase", 1, 5, 2982, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[7].p", "Absolute pressure of medium [Pa|bar]",\
 109, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[7].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[7].h", "Specific enthalpy of medium [J/kg]",\
 110, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[7].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1, 5, 2987, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[7].T", 1, 5, 2989, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[7].phase", 1, 5, 2986, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[7].h", 1, 1, 110,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1, 5, 2987,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].T", 1, 5, 2989,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[7].p", 1, 1, 109, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[7].p", 1, 1,\
 109, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[7].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[7].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[7].phase", 1, 5, 2986, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[8].p", "Absolute pressure of medium [Pa|bar]",\
 111, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[8].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[8].h", "Specific enthalpy of medium [J/kg]",\
 112, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[8].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1, 5, 2991, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[8].T", 1, 5, 2993, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[8].phase", 1, 5, 2990, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[8].h", 1, 1, 112,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1, 5, 2991,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].T", 1, 5, 2993,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[8].p", 1, 1, 111, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[8].p", 1, 1,\
 111, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[8].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[8].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[8].phase", 1, 5, 2990, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[9].p", "Absolute pressure of medium [Pa|bar]",\
 113, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[9].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[9].h", "Specific enthalpy of medium [J/kg]",\
 114, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[9].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1, 5, 2995, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[9].T", 1, 5, 2997, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].X[1]", "Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]",\
 1.0, 0.0,1.0,0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[9].phase", 1, 5, 2994, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[9].h", 1, 1, 114,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1, 5, 2995,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].T", 1, 5, 2997,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[9].p", 1, 1, 113, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[9].p", 1, 1,\
 113, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[9].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[9].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[9].phase", 1, 5, 2994, 66)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[10].p", "Absolute pressure of medium [Pa|bar]",\
 115, 100000.0, 611.657,100000000.0,100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[10].der(p)", \
"der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.STHX.tube.mediums[10].h", "Specific enthalpy of medium [J/kg]",\
 116, 0.0, -10000000000.0,10000000000.0,500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.mediums[10].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].d", "Density of medium [kg/m3|g/cm3]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[10].d", 1, 5, 2999, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].T", "Temperature of medium [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[10].T", 1, 5, 3001, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].u", "Specific internal energy of medium [J/kg]",\
 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].R_s", "Gas constant (of mixture if applicable) [J/(kg.K)]",\
 461.5231157345669, 0.0,10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].MM", "Molar mass (of mixture or single fluid) [kg/mol]",\
 0.018015268, 0.001,0.25,0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].state.phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[10].phase", 1, 5, 2998, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[10].h", 1, 1, 116,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].d", 1, 5, 2999,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].T", 1, 5, 3001,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[10].p", 1, 1, 115, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[10].p", 1,\
 1, 115, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.mediums[10].sat.Tsat", \
"Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.mediums[10].phase", "2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[10].phase", 1, 5, 2998, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[1].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[1].phase", 1, 5, 2962, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[1].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[1].h", 1, 1, 98,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[1].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].d", 1, 5, 2963,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[1].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].T", 1, 5, 2965,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[1].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[1].p", 1, 1, 97, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[2].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[2].phase", 1, 5, 2966, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[2].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[2].h", 1, 1, 100,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[2].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1, 5, 2967,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[2].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].T", 1, 5, 2969,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[2].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[2].p", 1, 1, 99, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[3].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[3].phase", 1, 5, 2970, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[3].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[3].h", 1, 1, 102,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[3].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1, 5, 2971,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[3].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].T", 1, 5, 2973,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[3].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[3].p", 1, 1, 101, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[4].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[4].phase", 1, 5, 2974, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[4].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[4].h", 1, 1, 104,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[4].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1, 5, 2975,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[4].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].T", 1, 5, 2977,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[4].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[4].p", 1, 1, 103, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[5].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[5].phase", 1, 5, 2978, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[5].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[5].h", 1, 1, 106,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[5].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1, 5, 2979,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[5].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].T", 1, 5, 2981,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[5].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[5].p", 1, 1, 105, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[6].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[6].phase", 1, 5, 2982, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[6].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[6].h", 1, 1, 108,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[6].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1, 5, 2983,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[6].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].T", 1, 5, 2985,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[6].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[6].p", 1, 1, 107, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[7].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[7].phase", 1, 5, 2986, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[7].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[7].h", 1, 1, 110,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[7].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1, 5, 2987,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[7].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].T", 1, 5, 2989,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[7].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[7].p", 1, 1, 109, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[8].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[8].phase", 1, 5, 2990, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[8].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[8].h", 1, 1, 112,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[8].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1, 5, 2991,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[8].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].T", 1, 5, 2993,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[8].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[8].p", 1, 1, 111, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[9].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[9].phase", 1, 5, 2994, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[9].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[9].h", 1, 1, 114,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[9].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1, 5, 2995,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[9].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].T", 1, 5, 2997,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[9].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[9].p", 1, 1, 113, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[10].phase", \
"Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[10].phase", 1, 5, 2998, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[10].h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[10].h", 1, 1, 116,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[10].d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].d", 1, 5, 2999,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].T", 1, 5, 3001,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.states[10].p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[10].p", 1, 1, 115, 0)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].k",\
 "Gain [1]", 524, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].y_start",\
 "Initial or guess value of output (= state)", 525, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].y", \
"Connector of Real output signal", 117, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[1].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].k",\
 "Gain [1]", 526, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].y_start",\
 "Initial or guess value of output (= state)", 527, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].y", \
"Connector of Real output signal", 118, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[2].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].k",\
 "Gain [1]", 528, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].y_start",\
 "Initial or guess value of output (= state)", 529, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].y", \
"Connector of Real output signal", 119, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[3].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].k",\
 "Gain [1]", 530, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].y_start",\
 "Initial or guess value of output (= state)", 531, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].y", \
"Connector of Real output signal", 120, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[4].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].k",\
 "Gain [1]", 532, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].y_start",\
 "Initial or guess value of output (= state)", 533, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].y", \
"Connector of Real output signal", 121, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[5].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].k",\
 "Gain [1]", 534, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].y_start",\
 "Initial or guess value of output (= state)", 535, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].y", \
"Connector of Real output signal", 122, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[6].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].k",\
 "Gain [1]", 536, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].y_start",\
 "Initial or guess value of output (= state)", 537, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].y", \
"Connector of Real output signal", 123, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[7].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].k",\
 "Gain [1]", 538, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].y_start",\
 "Initial or guess value of output (= state)", 539, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].y", \
"Connector of Real output signal", 124, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[8].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].k",\
 "Gain [1]", 540, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].T", \
"Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].y_start",\
 "Initial or guess value of output (= state)", 541, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].u", \
"Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].y", \
"Connector of Real output signal", 125, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tube.flowModel.firstOrder_dps_K[9].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[1].phase", 1, 5, 2962, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[1].h", 1, 1, 98,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].d", 1, 5, 2963,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].T", 1, 5, 2965,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[1].p", 1, 1, 97, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[1].h", 1,\
 1, 98, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].d", 1, 5,\
 2963, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].T", 1, 5,\
 2965, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[1].p", 1, 1, 97,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[1]", 1,\
 5, 2166, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[1].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[2].phase", 1, 5, 2966, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[2].h", 1, 1, 100,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1, 5, 2967,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].T", 1, 5, 2969,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[2].p", 1, 1, 99, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[2].h", 1,\
 1, 100, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1, 5,\
 2967, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].T", 1, 5,\
 2969, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[2].p", 1, 1, 99,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[2]", 1,\
 5, 2167, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[2].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[3].phase", 1, 5, 2970, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[3].h", 1, 1, 102,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1, 5, 2971,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].T", 1, 5, 2973,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[3].p", 1, 1, 101, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[3].h", 1,\
 1, 102, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1, 5,\
 2971, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].T", 1, 5,\
 2973, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[3].p", 1, 1, 101,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[3]", 1,\
 5, 2168, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[3].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[4].phase", 1, 5, 2974, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[4].h", 1, 1, 104,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1, 5, 2975,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].T", 1, 5, 2977,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[4].p", 1, 1, 103, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[4].h", 1,\
 1, 104, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1, 5,\
 2975, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].T", 1, 5,\
 2977, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[4].p", 1, 1, 103,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[4]", 1,\
 5, 2169, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[4].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[5].phase", 1, 5, 2978, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[5].h", 1, 1, 106,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1, 5, 2979,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].T", 1, 5, 2981,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[5].p", 1, 1, 105, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[5].h", 1,\
 1, 106, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1, 5,\
 2979, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].T", 1, 5,\
 2981, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[5].p", 1, 1, 105,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[5]", 1,\
 5, 2170, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[5].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[6].phase", 1, 5, 2982, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[6].h", 1, 1, 108,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1, 5, 2983,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].T", 1, 5, 2985,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[6].p", 1, 1, 107, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[6].h", 1,\
 1, 108, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1, 5,\
 2983, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].T", 1, 5,\
 2985, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[6].p", 1, 1, 107,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[6]", 1,\
 5, 2171, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[6].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[7].phase", 1, 5, 2986, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[7].h", 1, 1, 110,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1, 5, 2987,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].T", 1, 5, 2989,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[7].p", 1, 1, 109, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[7].h", 1,\
 1, 110, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1, 5,\
 2987, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].T", 1, 5,\
 2989, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[7].p", 1, 1, 109,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[7]", 1,\
 5, 2172, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[7].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[8].phase", 1, 5, 2990, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[8].h", 1, 1, 112,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1, 5, 2991,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].T", 1, 5, 2993,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[8].p", 1, 1, 111, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[8].h", 1,\
 1, 112, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1, 5,\
 2991, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].T", 1, 5,\
 2993, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[8].p", 1, 1, 111,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[8]", 1,\
 5, 2173, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[8].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[9].phase", 1, 5, 2994, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[9].h", 1, 1, 114,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1, 5, 2995,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].T", 1, 5, 2997,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[9].p", 1, 1, 113, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[9].h", 1,\
 1, 114, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1, 5,\
 2995, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].T", 1, 5,\
 2997, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[9].p", 1, 1, 113,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[9]", 1,\
 5, 2174, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[9].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.STHX.tube.statesFM[10].phase", 1, 5, 2998, 66)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[10].h", 1, 1, 116,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].d", 1, 5, 2999,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].T", 1, 5, 3001,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[10].p", 1, 1, 115, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].h", \
"Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.STHX.tube.mediums[10].h", 1,\
 1, 116, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].d", \
"Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].d", 1,\
 5, 2999, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].T", \
"Fluid temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].T", 1, 5,\
 3001, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].p", \
"Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.STHX.tube.mediums[10].p", 1, 1, 115,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].mu", \
"Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_b[9]", 1,\
 5, 2175, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].lambda", \
"Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.mediaProps[10].cp", \
"Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[1]", 1, 5, 3002, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[1].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[2]", 1, 5, 3003, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[2].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[3]", 1, 5, 3004, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[3].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[4]", 1, 5, 3005, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[4].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[5]", 1, 5, 3006, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[5].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[6]", 1, 5, 3007, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[6].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[7]", 1, 5, 3008, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[7].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[8]", 1, 5, 3009, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[8].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].diameter_a", \
"Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].diameter_b", \
"Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.data.d_steamGenerator_tube_inner", 1,\
 5, 5523, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].crossArea_a", \
"Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].crossArea_b", \
"Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.STHX.geometry.crossAreas_tube[1]", 1,\
 5, 688, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].length", \
"Length of pipe [m]", "nuScaleModule_v5_1.STHX.tube.dlengthsFM[9]", 1, 5, 3010, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].roughness_a", \
"Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].roughness_b", \
"Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.STHX.tube.flowModel.IN_con[9].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[1].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[1].d", 1,\
 5, 2963, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[1].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1,\
 5, 2967, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[1].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[1]", 1,\
 5, 2166, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[1].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[2]", 1,\
 5, 2167, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[2].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[2].d", 1,\
 5, 2967, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[2].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1,\
 5, 2971, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[2].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[2]", 1,\
 5, 2167, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[2].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[3]", 1,\
 5, 2168, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[3].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[3].d", 1,\
 5, 2971, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[3].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1,\
 5, 2975, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[3].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[3]", 1,\
 5, 2168, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[3].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[4]", 1,\
 5, 2169, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[4].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[4].d", 1,\
 5, 2975, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[4].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1,\
 5, 2979, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[4].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[4]", 1,\
 5, 2169, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[4].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[5]", 1,\
 5, 2170, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[5].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[5].d", 1,\
 5, 2979, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[5].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1,\
 5, 2983, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[5].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[5]", 1,\
 5, 2170, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[5].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[6]", 1,\
 5, 2171, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[6].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[6].d", 1,\
 5, 2983, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[6].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1,\
 5, 2987, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[6].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[6]", 1,\
 5, 2171, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[6].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[7]", 1,\
 5, 2172, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[7].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[7].d", 1,\
 5, 2987, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[7].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1,\
 5, 2991, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[7].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[7]", 1,\
 5, 2172, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[7].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[8]", 1,\
 5, 2173, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[8].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[8].d", 1,\
 5, 2991, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[8].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1,\
 5, 2995, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[8].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[8]", 1,\
 5, 2173, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[8].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[9]", 1,\
 5, 2174, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[9].rho_a", \
"Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[9].d", 1,\
 5, 2995, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[9].rho_b", \
"Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.STHX.tube.statesFM[10].d", 1,\
 5, 2999, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[9].mu_a", \
"Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_a[9]", 1,\
 5, 2174, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tube.flowModel.IN_var[9].mu_b", \
"Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.STHX.tube.flowModel.mus_b[9]", 1,\
 5, 2175, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].T", \
"Temperature [K|degC]", 126, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].h", 1,\
 5, 6252, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].T", \
"Temperature [K|degC]", 127, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].h", 1,\
 5, 6257, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].T", \
"Temperature [K|degC]", 128, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].h", 1,\
 5, 6262, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].T", \
"Temperature [K|degC]", 129, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].h", 1,\
 5, 6267, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].T", \
"Temperature [K|degC]", 130, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].h", 1,\
 5, 6272, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 5].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].T", \
"Temperature [K|degC]", 131, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].h", 1,\
 5, 6277, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 6].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].T", \
"Temperature [K|degC]", 132, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].h", 1,\
 5, 6282, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 7].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].T", \
"Temperature [K|degC]", 133, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].h", 1,\
 5, 6287, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 8].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].T", \
"Temperature [K|degC]", 134, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].h", 1,\
 5, 6292, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 9].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].T", \
"Temperature [K|degC]", 135, 300.0, 273.15,1773.15,300.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].h", 1,\
 5, 6297, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[1, 10].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].T", \
"Temperature [K|degC]", 136, 558.31341553, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].h", 1,\
 5, 6302, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].T", \
"Temperature [K|degC]", 137, 562.8692627, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].h", 1,\
 5, 6307, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].T", \
"Temperature [K|degC]", 138, 568.02947998, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].h", 1,\
 5, 6312, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].T", \
"Temperature [K|degC]", 139, 572.29638672, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].h", 1,\
 5, 6317, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].T", \
"Temperature [K|degC]", 140, 576.52716064, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].h", 1,\
 5, 6322, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 5].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].T", \
"Temperature [K|degC]", 141, 580.78710938, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].h", 1,\
 5, 6327, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 6].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].T", \
"Temperature [K|degC]", 142, 585.11022949, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].h", 1,\
 5, 6332, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 7].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].T", \
"Temperature [K|degC]", 143, 589.5078125, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].h", 1,\
 5, 6337, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 8].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].T", \
"Temperature [K|degC]", 144, 593.97235107, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].h", 1,\
 5, 6342, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 9].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 false, 0.0,0.0,0.0,0,515)
DeclareState("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].T", \
"Temperature [K|degC]", 145, 596.58215332, 273.15,1773.15,300.0,0,560)
DeclareDerivative("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].der(T)", \
"der(Temperature) [K/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].h", \
"Specific enthalpy of medium [J/kg]", 0.0, -100000000.0,100000000.0,1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].der(h)", \
"der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].d", \
"Density of medium [kg/m3|g/cm3]", 8030, 0.0,100000.0,1.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].u", \
"Specific internal energy of medium [J/kg]", "nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].h", 1,\
 5, 6347, 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.1, 0.0,1E+100,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.materials[2, 10].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 7].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 8].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 9].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[1, 10].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 7].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 8].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 9].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_1[2, 10].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 7].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 8].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 9].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[1, 10].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 7].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 8].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 9].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.conductionModel.states_2[2, 10].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 7].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 8].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 9].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[1, 10].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 7].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 8].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 9].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.internalHeatModel.states[2, 10].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 0)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[1].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[1].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[2].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[2].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[3].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[3].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[4].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[4].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[5].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[5].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[6].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[6].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[7].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[7].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[8].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[8].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[9].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[9].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a1[10].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,776)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a1[10].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[1].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[1].Q_flow", -1, 5, 940, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[1].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[2].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[2].Q_flow", -1, 5, 941, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[2].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[3].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[3].Q_flow", -1, 5, 942, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[3].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[4].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[4].Q_flow", -1, 5, 943, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[4].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[5].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[5].Q_flow", -1, 5, 944, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[5].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[6].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[6].Q_flow", -1, 5, 945, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[6].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[7].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[7].Q_flow", -1, 5, 946, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[7].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[8].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[8].Q_flow", -1, 5, 947, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[8].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[9].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[9].Q_flow", -1, 5, 948, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[9].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[10].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 "nuScaleModule_v5_1.STHX.counterFlow.port_a[10].Q_flow", -1, 5, 949, 132)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b1[10].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a2[1].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a2[1].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_a2[2].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_a2[2].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_b2[1].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b2[1].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_b2[2].Q_flow", \
"Heat flow rate. Flow from the connection point into the component is positive. [W]",\
 0.0, 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_b2[2].T", "Temperature at the connection point [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728, 4)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 1].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5,\
 2924, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 1].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 2].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5,\
 2925, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 2].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 3].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5,\
 2926, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 3].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 4].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5,\
 2927, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 4].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 5].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5,\
 2928, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 5].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 6].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5,\
 2929, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 6].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 7].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5,\
 2930, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 7].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 8].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5,\
 2931, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 8].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 9].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5,\
 2932, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 9].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 10].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5,\
 2933, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[1, 10].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 1].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5,\
 1737, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 1].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 2].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5,\
 1736, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 2].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 3].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5,\
 1735, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 3].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 4].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5,\
 1734, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 4].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 5].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5,\
 1733, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 5].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 6].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5,\
 1732, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 6].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 7].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5,\
 1731, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 7].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 8].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5,\
 1730, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 8].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 9].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5,\
 1729, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 9].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 10].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5,\
 1728, 4)
DeclareVariable("nuScaleModule_v5_1.STHX.tubeWall.port_external[2, 10].Q_flow", \
"Heat flow rate (positive if flowing from outside into the component) [W]", 0.0,\
 0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[1].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[2].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[3].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[4].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[5].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[6].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[7].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[8].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[9].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a1[10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[1].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[2].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[3].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[4].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[5].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[6].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[7].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[8].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[9].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b1[10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 0)
EndNonAlias(5)
PreNonAliasNew(6)
StartNonAlias(6)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a2[1].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_a2[2].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b2[1].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.state_b2[2].T", "Temperature [K|degC]",\
 "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728, 0)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 1].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 2].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 3].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 4].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 5].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 6].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 7].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 8].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 9].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[1, 10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 1].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 2].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 3].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 4].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 5].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 6].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 7].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 8].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 9].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_1[2, 10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 1].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[1, 1]", 1, 5, 2924,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 2].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[2, 1]", 1, 5, 2925,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 3].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[3, 1]", 1, 5, 2926,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 4].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[4, 1]", 1, 5, 2927,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 5].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[5, 1]", 1, 5, 2928,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 6].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[6, 1]", 1, 5, 2929,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 7].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[7, 1]", 1, 5, 2930,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 8].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[8, 1]", 1, 5, 2931,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 9].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[9, 1]", 1, 5, 2932,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[1, 10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.tube.Ts_wall[10, 1]", 1, 5, 2933,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 1].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[10, 1]", 1, 5, 1737,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 2].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[9, 1]", 1, 5, 1736,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 3].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[8, 1]", 1, 5, 1735,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 4].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[7, 1]", 1, 5, 1734,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 5].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[6, 1]", 1, 5, 1733,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 6].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[5, 1]", 1, 5, 1732,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 7].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[4, 1]", 1, 5, 1731,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 8].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[3, 1]", 1, 5, 1730,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 9].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[2, 1]", 1, 5, 1729,\
 1024)
DeclareAlias2("nuScaleModule_v5_1.STHX.tubeWall.statesFM_2[2, 10].T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.STHX.shell.Ts_wall[1, 1]", 1, 5, 1728,\
 1024)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p", \
"Absolute pressure of medium [Pa|bar]", 146, 100000.0, 611.657,100000000.0,\
100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].der(p)",\
 "der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].h", \
"Specific enthalpy of medium [J/kg]", 147, 0.0, -10000000000.0,10000000000.0,\
500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].der(h)",\
 "der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].d", \
"Density of medium [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].T", \
"Temperature of medium [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 1]", 1,\
 5, 5334, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].u", \
"Specific internal energy of medium [J/kg]", 0.0, -100000000.0,100000000.0,\
1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.018015268, 0.001,0.25,\
0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].phase", 1, 5, 4716, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].h", 1,\
 1, 147, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 1]", 1,\
 5, 5334, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p", 1,\
 1, 146, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p", 1,\
 1, 146, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].sat.Tsat",\
 "Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].phase", 1, 5, 4716, 66)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p", \
"Absolute pressure of medium [Pa|bar]", 148, 100000.0, 611.657,100000000.0,\
100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].der(p)",\
 "der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].h", \
"Specific enthalpy of medium [J/kg]", 149, 0.0, -10000000000.0,10000000000.0,\
500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].der(h)",\
 "der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].d", \
"Density of medium [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].T", \
"Temperature of medium [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 2]", 1,\
 5, 5335, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].u", \
"Specific internal energy of medium [J/kg]", 0.0, -100000000.0,100000000.0,\
1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.018015268, 0.001,0.25,\
0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].phase", 1, 5, 4719, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].h", 1,\
 1, 149, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 2]", 1,\
 5, 5335, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p", 1,\
 1, 148, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p", 1,\
 1, 148, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].sat.Tsat",\
 "Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].phase", 1, 5, 4719, 66)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p", \
"Absolute pressure of medium [Pa|bar]", 150, 100000.0, 611.657,100000000.0,\
100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].der(p)",\
 "der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].h", \
"Specific enthalpy of medium [J/kg]", 151, 0.0, -10000000000.0,10000000000.0,\
500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].der(h)",\
 "der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].d", \
"Density of medium [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].T", \
"Temperature of medium [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 3]", 1,\
 5, 5336, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].u", \
"Specific internal energy of medium [J/kg]", 0.0, -100000000.0,100000000.0,\
1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.018015268, 0.001,0.25,\
0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].phase", 1, 5, 4722, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].h", 1,\
 1, 151, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 3]", 1,\
 5, 5336, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p", 1,\
 1, 150, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p", 1,\
 1, 150, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].sat.Tsat",\
 "Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].phase", 1, 5, 4722, 66)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p", \
"Absolute pressure of medium [Pa|bar]", 152, 100000.0, 611.657,100000000.0,\
100000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].der(p)",\
 "der(Absolute pressure of medium) [Pa/s]", 0.0, 0.0,0.0,0.0,0,512)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].h", \
"Specific enthalpy of medium [J/kg]", 153, 0.0, -10000000000.0,10000000000.0,\
500000.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].der(h)",\
 "der(Specific enthalpy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].d", \
"Density of medium [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].T", \
"Temperature of medium [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 4]", 1,\
 5, 5337, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].X[1]", \
"Mass fractions (= (component mass)/total mass  m_i/m) [kg/kg]", 1.0, 0.0,1.0,\
0.1,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].u", \
"Specific internal energy of medium [J/kg]", 0.0, -100000000.0,100000000.0,\
1000000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].der(u)", \
"der(Specific internal energy of medium) [m2/s3]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].R_s", \
"Gas constant (of mixture if applicable) [J/(kg.K)]", 461.5231157345669, 0.0,\
10000000.0,1000.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].MM", \
"Molar mass (of mixture or single fluid) [kg/mol]", 0.018015268, 0.001,0.25,\
0.032,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].phase", 1, 5, 4725, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].state.h", \
"Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].h", 1,\
 1, 153, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].state.d", \
"Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].state.T", \
"Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 4]", 1,\
 5, 5337, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].state.p", \
"Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p", 1,\
 1, 152, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].preferredMediumStates",\
 "= true if StateSelect.prefer shall be used for the independent property variables of the medium [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].standardOrderComponents",\
 "If true, and reducedX = true, the last element of X will be computed from the other ones [:#(type=Boolean)]",\
 true, 0.0,0.0,0.0,0,515)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].T_degC", \
"Temperature of medium in [degC] [degC;]", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p_bar", \
"Absolute pressure of medium in [bar] [bar]", 0.0, 0.0,0.0,0.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].sat.psat", \
"Saturation pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p", 1,\
 1, 152, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].sat.Tsat",\
 "Saturation temperature [K|degC]", 500, 273.15,2273.15,500.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].phase", \
"2 for two-phase, 1 for one-phase, 0 if not known [:#(type=Integer)]", \
"nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].phase", 1, 5, 4725, 66)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[1].phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 0, 0.0,2.0,0.0,0,517)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[1].h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.DownComer.mediums[2].h", 1, 1, 63,\
 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[1].d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.d", 1,\
 5, 4680, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[1].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.T", 1,\
 5, 4681, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[1].p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[2].p", 1, 1, 62, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[2].phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].phase", 1, 5, 4716, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[2].h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].h", 1,\
 1, 147, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[2].d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[2].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 1]", 1,\
 5, 5334, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[2].p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p", 1,\
 1, 146, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[3].phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].phase", 1, 5, 4719, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[3].h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].h", 1,\
 1, 149, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[3].d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[3].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 2]", 1,\
 5, 5335, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[3].p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p", 1,\
 1, 148, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[4].phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].phase", 1, 5, 4722, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[4].h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].h", 1,\
 1, 151, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[4].d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[4].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 3]", 1,\
 5, 5336, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[4].p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p", 1,\
 1, 150, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[5].phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].phase", 1, 5, 4725, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[5].h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].h", 1,\
 1, 153, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[5].d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[5].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 4]", 1,\
 5, 5337, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[5].p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p", 1,\
 1, 152, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[6].phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 0, 0.0,2.0,0.0,0,517)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[6].h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].h", 1, 1,\
 57, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[6].d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.d", 1,\
 5, 4683, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[6].T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.T", 1,\
 5, 4684, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.states[6].p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].p", 1, 1, 56, 0)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].k",\
 "Gain [1]", 542, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].y_start",\
 "Initial or guess value of output (= state)", 543, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].y",\
 "Connector of Real output signal", 154, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[1].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].k",\
 "Gain [1]", 544, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].y_start",\
 "Initial or guess value of output (= state)", 545, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].y",\
 "Connector of Real output signal", 155, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[2].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].k",\
 "Gain [1]", 546, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].y_start",\
 "Initial or guess value of output (= state)", 547, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].y",\
 "Connector of Real output signal", 156, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[3].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].k",\
 "Gain [1]", 548, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].y_start",\
 "Initial or guess value of output (= state)", 549, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].y",\
 "Connector of Real output signal", 157, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[4].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].k",\
 "Gain [1]", 550, 1, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].T",\
 "Time Constant [s]", 1, 0.0,0.0,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].initType",\
 "Type of initialization (1: no init, 2: steady state, 3/4: initial output) [:#(type=Modelica.Blocks.Types.Init)]",\
 4, 1.0,4.0,0.0,0,517)
DeclareParameter("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].y_start",\
 "Initial or guess value of output (= state)", 551, 0, 0.0,0.0,0.0,0,560)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].u",\
 "Connector of Real input signal", 0.0, 0.0,0.0,0.0,0,513)
DeclareState("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].y",\
 "Connector of Real output signal", 158, 0.0, 0.0,0.0,0.0,0,544)
DeclareDerivative("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.firstOrder_dps_K[5].der(y)",\
 "der(Connector of Real output signal)", 0.0, 0.0,0.0,0.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 0, 0.0,2.0,0.0,0,517)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].state.h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.DownComer.mediums[2].h", 1, 1, 63,\
 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].state.d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.d", 1,\
 5, 4680, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].state.T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.T", 1,\
 5, 4681, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].state.p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[2].p", 1, 1, 62, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].h",\
 "Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.DownComer.mediums[2].h", 1,\
 1, 63, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].d",\
 "Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.d", 1,\
 5, 4680, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].T",\
 "Fluid temperature [K|degC]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.T", 1,\
 5, 4681, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].p",\
 "Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.DownComer.mediums[2].p", 1, 1, 62,\
 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].mu",\
 "Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[1]", 1,\
 5, 4506, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[1].cp",\
 "Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].phase", 1, 5, 4716, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].state.h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].h", 1,\
 1, 147, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].state.d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].state.T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 1]", 1,\
 5, 5334, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].state.p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p", 1,\
 1, 146, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].h",\
 "Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].h", 1,\
 1, 147, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].d",\
 "Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].T",\
 "Fluid temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 1]", 1,\
 5, 5334, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].p",\
 "Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[1].p", 1,\
 1, 146, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].mu",\
 "Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[2]", 1,\
 5, 4507, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[2].cp",\
 "Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].phase", 1, 5, 4719, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].state.h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].h", 1,\
 1, 149, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].state.d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].state.T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 2]", 1,\
 5, 5335, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].state.p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p", 1,\
 1, 148, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].h",\
 "Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].h", 1,\
 1, 149, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].d",\
 "Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].T",\
 "Fluid temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 2]", 1,\
 5, 5335, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].p",\
 "Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[2].p", 1,\
 1, 148, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].mu",\
 "Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[3]", 1,\
 5, 4508, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[3].cp",\
 "Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].phase", 1, 5, 4722, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].state.h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].h", 1,\
 1, 151, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].state.d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].state.T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 3]", 1,\
 5, 5336, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].state.p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p", 1,\
 1, 150, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].h",\
 "Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].h", 1,\
 1, 151, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].d",\
 "Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].T",\
 "Fluid temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 3]", 1,\
 5, 5336, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].p",\
 "Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[3].p", 1,\
 1, 150, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].mu",\
 "Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[4]", 1,\
 5, 4509, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[4].cp",\
 "Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].phase", 1, 5, 4725, 66)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].state.h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].h", 1,\
 1, 153, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].state.d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].state.T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 4]", 1,\
 5, 5337, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].state.p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p", 1,\
 1, 152, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].h",\
 "Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].h", 1,\
 1, 153, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].d",\
 "Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].T",\
 "Fluid temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 4]", 1,\
 5, 5337, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].p",\
 "Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.core.coolantSubchannel.mediums[4].p", 1,\
 1, 152, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].mu",\
 "Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[5]", 1,\
 5, 4510, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[5].cp",\
 "Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].state.phase",\
 "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use [:#(type=Integer)]",\
 0, 0.0,2.0,0.0,0,517)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].state.h",\
 "Specific enthalpy [J/kg]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].h", 1, 1,\
 57, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].state.d",\
 "Density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.d", 1,\
 5, 4683, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].state.T",\
 "Temperature [K|degC]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.T", 1,\
 5, 4684, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].state.p",\
 "Pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].p", 1, 1, 56, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].h",\
 "Fluid specific enthalpy [J/kg]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].h", 1,\
 1, 57, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].d",\
 "Fluid density [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.d", 1,\
 5, 4683, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].T",\
 "Fluid temperature [K|degC]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.T", 1,\
 5, 4684, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].p",\
 "Fluid pressure [Pa|bar]", "nuScaleModule_v5_1.Lower_Riser.mediums[1].p", 1, 1,\
 56, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].mu",\
 "Dynamic viscosity [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_b[5]", 1,\
 5, 4511, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].lambda",\
 "Thermal conductivity [W/(m.K)]", 1, 0.0,500.0,1.0,0,512)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mediaProps[6].cp",\
 "Specific heat capacity [J/(kg.K)]", 1000.0, 0.0,10000000.0,1000.0,0,512)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].diameter_a",\
 "Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[1]", 1,\
 5, 4741, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].diameter_b",\
 "Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[1]", 1,\
 5, 4741, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].crossArea_a",\
 "Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].crossArea_b",\
 "Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].length",\
 "Length of pipe [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dlengthsFM[1]", 1,\
 5, 4731, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[1].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].diameter_a",\
 "Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[1]", 1,\
 5, 4741, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].diameter_b",\
 "Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[3]", 1,\
 5, 4742, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].crossArea_a",\
 "Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].crossArea_b",\
 "Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].length",\
 "Length of pipe [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dlengthsFM[2]", 1,\
 5, 4732, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[2].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].diameter_a",\
 "Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[3]", 1,\
 5, 4742, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].diameter_b",\
 "Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[4]", 1,\
 5, 4743, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].crossArea_a",\
 "Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].crossArea_b",\
 "Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].length",\
 "Length of pipe [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dlengthsFM[3]", 1,\
 5, 4733, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[3].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].diameter_a",\
 "Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[4]", 1,\
 5, 4743, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].diameter_b",\
 "Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[5]", 1,\
 5, 4744, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].crossArea_a",\
 "Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].crossArea_b",\
 "Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].length",\
 "Length of pipe [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dlengthsFM[4]", 1,\
 5, 4734, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[4].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].diameter_a",\
 "Inner (hydraulic) diameter at port_a [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[5]", 1,\
 5, 4744, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].diameter_b",\
 "Inner (hydraulic) diameter at port_b [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dimensionsFM[5]", 1,\
 5, 4744, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].crossArea_a",\
 "Inner cross section area at port_a [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].crossArea_b",\
 "Inner cross section area at port_b [m2]", "nuScaleModule_v5_1.core.geometry.crossArea", 1,\
 5, 3789, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].length",\
 "Length of pipe [m]", "nuScaleModule_v5_1.core.coolantSubchannel.dlengthsFM[5]", 1,\
 5, 4735, 0)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].roughness_a",\
 "Absolute roughness of pipe at port_a, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].roughness_b",\
 "Absolute roughness of pipe at port_b, with a default for a smooth steel pipe [m]",\
 2.5E-05, 0.0,1E+100,0.0,0,513)
DeclareVariable("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_con[5].Re_turbulent",\
 "Turbulent transition point if Re >= Re_turbulent [1]", 4000, 0.0,0.0,0.0,0,513)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[1].rho_a",\
 "Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_a.d", 1,\
 5, 4680, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[1].rho_b",\
 "Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[1].mu_a",\
 "Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[1]", 1,\
 5, 4506, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[1].mu_b",\
 "Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[2]", 1,\
 5, 4507, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[2].rho_a",\
 "Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[2].d", 1,\
 5, 4717, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[2].rho_b",\
 "Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[2].mu_a",\
 "Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[2]", 1,\
 5, 4507, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[2].mu_b",\
 "Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[3]", 1,\
 5, 4508, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[3].rho_a",\
 "Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[3].d", 1,\
 5, 4720, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[3].rho_b",\
 "Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[3].mu_a",\
 "Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[3]", 1,\
 5, 4508, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[3].mu_b",\
 "Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[4]", 1,\
 5, 4509, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[4].rho_a",\
 "Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[4].d", 1,\
 5, 4723, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[4].rho_b",\
 "Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[4].mu_a",\
 "Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[4]", 1,\
 5, 4509, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[4].mu_b",\
 "Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[5]", 1,\
 5, 4510, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[5].rho_a",\
 "Density at port_a [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.statesFM[5].d", 1,\
 5, 4726, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[5].rho_b",\
 "Density at port_b [kg/m3|g/cm3]", "nuScaleModule_v5_1.core.coolantSubchannel.state_b.d", 1,\
 5, 4683, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[5].mu_a",\
 "Dynamic viscosity at port_a [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_a[5]", 1,\
 5, 4510, 0)
DeclareAlias2("nuScaleModule_v5_1.core.coolantSubchannel.flowModel.IN_var[5].mu_b",\
 "Dynamic viscosity at port_b [Pa.s]", "nuScaleModule_v5_1.core.coolantSubchannel.flowModel.mus_b[5]", 1,\
 5, 4511, 0)
DeclareAlias2("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD2.port[1].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_1.solutionMethod.Ts[3, 4]", 1,\
 1, 37, 4)
DeclareVariable("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD2.port[1].Q_flow",\
 "Heat flow rate (positive if flowing from outside into the component) [W]", 0, \
0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD2.port[2].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_2.solutionMethod.Ts[2, 4]", 1,\
 1, 41, 4)
DeclareVariable("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD2.port[2].Q_flow",\
 "Heat flow rate (positive if flowing from outside into the component) [W]", 0, \
0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD2.port[3].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_2.solutionMethod.Ts[3, 4]", 1,\
 1, 45, 4)
DeclareVariable("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD2.port[3].Q_flow",\
 "Heat flow rate (positive if flowing from outside into the component) [W]", 0, \
0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD4.port[1].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_2.solutionMethod.Ts[3, 4]", 1,\
 1, 45, 4)
DeclareVariable("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD4.port[1].Q_flow",\
 "Heat flow rate (positive if flowing from outside into the component) [W]", 0, \
0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD4.port[2].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[2, 4]", 1,\
 1, 49, 4)
DeclareVariable("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD4.port[2].Q_flow",\
 "Heat flow rate (positive if flowing from outside into the component) [W]", 0, \
0.0,0.0,0.0,0,777)
DeclareAlias2("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD4.port[3].T", \
"Port temperature [K|degC]", "nuScaleModule_v5_1.core.fuelModel.region_3.solutionMethod.Ts[3, 4]", 1,\
 5, 5337, 4)
DeclareVariable("nuScaleModule_v5_1.core.fuelModel.adiabatic_FD4.port[3].Q_flow",\
 "Heat flow rate (positive if flowing from outside into the component) [W]", 0, \
0.0,0.0,0.0,0,777)
EndNonAlias(6)
PreNonAliasNew(7)
